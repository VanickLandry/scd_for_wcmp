<?php
/*
  Plugin Name: SCD - Smart Currency Detector - Variant for WCMP
  Plugin URI: http://gajelabs.com/product
  Description: This wordpress / woocommerce plugin is an ALL-IN-ONE solution for online market places owners, sellers, end customers. Multivendors variant
  Version: 1.0.0
  WC tested up to: 6.4
  Author: GaJeLabs
  Author URI: http://gajelabs.com
 */
if (in_array('scd-smart-currency-detector/index.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    require 'scd_wcmp _multivendor.php';
    include 'includes/index.php';
    include 'scd_multivendors_renders.php';
}

//$scd_plugin_folder = 'scd-standard';
define('SCDS_PLUGIN_DIR_PATH', plugin_dir_path(__FILE__));

function scd_multi_add_scrypt_topost()
{
    wp_enqueue_script("scd-wcmp-multivendor", trailingslashit(plugins_url("", __FILE__)) . "js/scd_wcmp_multivendor.js", array("jquery"));
    $variable_to_post = [
       'ajax_url' => admin_url('admin-ajax.php') 
    ];
    wp_localize_script('scd-wcmp-multivendor', 'scd_ajax', $variable_to_post);
}
add_action('wp_enqueue_scripts', 'scd_multi_add_scrypt_topost');

add_action('admin_notices', 'scd_premium_require');
function scd_premium_require()
{
    if (!is_plugin_active('scd-smart-currency-detector/index.php')) {
        echo '<h3 style="color:red;">SCD scd-smart-currency-detector-variant-for-wcmp require scd-smart-currency-detector-free-variant before use, please <a target="__blank" href="https://wordpress.org/plugins/scd-smart-currency-detector/"> download and install it here</a><h3>';
    }
}